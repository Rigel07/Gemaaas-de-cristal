package com.gemascute.registry;

import com.gemascute.GemasCuteMod;
import com.gemascute.entity.GemType;
import com.gemascute.item.CharmItem;
import com.gemascute.item.CloudStaffItem;
import com.gemascute.item.ConchItem;
import com.gemascute.item.DetectorItem;
import com.gemascute.item.DiamondItem;
import com.gemascute.item.DiamondScepterItem;
import com.gemascute.item.DiamondType;
import com.gemascute.item.GemoidEggItem;
import com.gemascute.item.HealingPearlItem;
import com.gemascute.item.LimonadeItem;
import com.gemascute.item.LunitaWandItem;
import com.gemascute.item.PinkitaSwordItem;
import com.gemascute.item.PrismItem;
import com.gemascute.item.SkyItem;
import java.util.List;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.BoneMealItem;
import net.minecraft.world.item.HoeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ShovelItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, GemasCuteMod.MODID);

    // ---- Las 13 gemas ----
    public static final RegistryObject<Item> PINKITA = gem("pinkita", Rarity.COMMON);
    public static final RegistryObject<Item> MENTITA = gem("mentita", Rarity.COMMON);
    public static final RegistryObject<Item> JELLITA = gem("jellita", Rarity.UNCOMMON);
    public static final RegistryObject<Item> ESTRELLITA = gem("estrellita", Rarity.UNCOMMON);
    public static final RegistryObject<Item> LUNITA = gem("lunita", Rarity.RARE);
    public static final RegistryObject<Item> SOLITA = gem("solita", Rarity.RARE);
    public static final RegistryObject<Item> BERRITA = gem("berrita", Rarity.EPIC);
    public static final RegistryObject<Item> CIELITA = gem("cielita", Rarity.RARE);
    public static final RegistryObject<Item> LIMONITA = gem("limonita", Rarity.COMMON);
    public static final RegistryObject<Item> CORALITA = gem("coralita", Rarity.UNCOMMON);
    public static final RegistryObject<Item> PERLITA = gem("perlita", Rarity.RARE);
    public static final RegistryObject<Item> CHOCOLITA = gem("chocolita", Rarity.COMMON);
    public static final RegistryObject<Item> IRIDITA = gem("iridita", Rarity.EPIC);

    // ---- Rubi y Zafiro ----
    public static final RegistryObject<Item> RUBI = gem("rubi", Rarity.RARE);
    public static final RegistryObject<Item> ZAFIRO = gem("zafiro", Rarity.RARE);

    // ---- Mentita: fertilizante (funciona como harina de hueso) ----
    public static final RegistryObject<Item> MENTITA_DUST = ITEMS.register("mentita_dust",
            () -> new BoneMealItem(new Item.Properties()));

    // ---- Pinkita: herramientas ----
    public static final RegistryObject<Item> PINKITA_SWORD = ITEMS.register("pinkita_sword",
            () -> new PinkitaSwordItem(ModTiers.PINKITA, 3, -2.4F, new Item.Properties()));
    public static final RegistryObject<Item> PINKITA_PICKAXE = ITEMS.register("pinkita_pickaxe",
            () -> new PickaxeItem(ModTiers.PINKITA, 1, -2.8F, new Item.Properties()));
    public static final RegistryObject<Item> PINKITA_AXE = ITEMS.register("pinkita_axe",
            () -> new AxeItem(ModTiers.PINKITA, 5.0F, -3.0F, new Item.Properties()));
    public static final RegistryObject<Item> PINKITA_SHOVEL = ITEMS.register("pinkita_shovel",
            () -> new ShovelItem(ModTiers.PINKITA, 1.5F, -3.0F, new Item.Properties()));
    public static final RegistryObject<Item> PINKITA_HOE = ITEMS.register("pinkita_hoe",
            () -> new HoeItem(ModTiers.PINKITA, -1, -1.0F, new Item.Properties()));

    // ---- Lunita: varita de salto lunar ----
    public static final RegistryObject<Item> LUNITA_WAND = ITEMS.register("lunita_wand",
            () -> new LunitaWandItem(new Item.Properties().durability(60).rarity(Rarity.RARE)));

    // ---- Solita: amuleto (fuego + prisa) ----
    public static final RegistryObject<Item> SOLITA_AMULET = ITEMS.register("solita_amulet",
            () -> new CharmItem(new Item.Properties().stacksTo(1).rarity(Rarity.RARE), () -> List.of(
                    new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 100, 0, true, false, true),
                    new MobEffectInstance(MobEffects.DIG_SPEED, 100, 0, true, false, true))));

    // ---- Berrita: corazon de vida extra ----
    public static final RegistryObject<Item> BERRITA_HEART = ITEMS.register("berrita_heart",
            () -> new Item(new Item.Properties().rarity(Rarity.EPIC).food(new FoodProperties.Builder()
                    .nutrition(6)
                    .saturationMod(1.0F)
                    .alwaysEat()
                    .effect(() -> new MobEffectInstance(MobEffects.HEALTH_BOOST, 6000, 2), 1.0F)
                    .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 200, 1), 1.0F)
                    .effect(() -> new MobEffectInstance(MobEffects.ABSORPTION, 2400, 1), 1.0F)
                    .build())));

    // ---- Cielita: baculo que te lanza al cielo ----
    public static final RegistryObject<Item> CIELITA_STAFF = ITEMS.register("cielita_staff",
            () -> new CloudStaffItem(new Item.Properties().durability(40).rarity(Rarity.RARE)));

    // ---- Limonita: limonada que limpia efectos malos ----
    public static final RegistryObject<Item> LIMONADE = ITEMS.register("limonade",
            () -> new LimonadeItem(new Item.Properties().stacksTo(16)));

    // ---- Coralita: concha marina (respirar bajo el agua) ----
    public static final RegistryObject<Item> CORALITA_SHELL = ITEMS.register("coralita_shell",
            () -> new CharmItem(new Item.Properties().stacksTo(1).rarity(Rarity.RARE), () -> List.of(
                    new MobEffectInstance(MobEffects.WATER_BREATHING, 100, 0, true, false, true),
                    new MobEffectInstance(MobEffects.DOLPHINS_GRACE, 100, 0, true, false, true))));

    // ---- Perlita: perla curativa ----
    public static final RegistryObject<Item> PERLITA_PEARL = ITEMS.register("perlita_pearl",
            () -> new HealingPearlItem(new Item.Properties().durability(6).rarity(Rarity.RARE)));

    // ---- Chocolita: barra de chocolate ----
    public static final RegistryObject<Item> CHOCOLITA_BAR = ITEMS.register("chocolita_bar",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .nutrition(8)
                    .saturationMod(1.2F)
                    .effect(() -> new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 200, 0), 1.0F)
                    .build())));

    // ---- Iridita: amuleto arcoiris (suerte + velocidad) ----
    public static final RegistryObject<Item> IRIDITA_AMULET = ITEMS.register("iridita_amulet",
            () -> new CharmItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC), () -> List.of(
                    new MobEffectInstance(MobEffects.LUCK, 100, 1, true, false, true),
                    new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 100, 0, true, false, true))));

    // ======================================================================
    // Nuevas funciones para las gemas de siempre
    // ======================================================================

    // ---- Pinkita: piruleta que cura y da corazones extra ----
    public static final RegistryObject<Item> PINKITA_LOLLIPOP = ITEMS.register("pinkita_lollipop",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .nutrition(3).saturationMod(0.4F).fast()
                    .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 100, 1), 1.0F)
                    .effect(() -> new MobEffectInstance(MobEffects.ABSORPTION, 600, 0), 1.0F)
                    .build())));

    // ---- Jellita: gominolas saltarinas ----
    public static final RegistryObject<Item> JELLITA_GUMMIES = ITEMS.register("jellita_gummies",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .nutrition(2).saturationMod(0.3F).fast()
                    .effect(() -> new MobEffectInstance(MobEffects.JUMP, 400, 2), 1.0F)
                    .effect(() -> new MobEffectInstance(MobEffects.SLOW_FALLING, 200, 0), 1.0F)
                    .build())));

    // ---- Berrita: tartaleta con muchos corazones dorados ----
    public static final RegistryObject<Item> BERRITA_TART = ITEMS.register("berrita_tart",
            () -> new Item(new Item.Properties().rarity(Rarity.UNCOMMON).food(new FoodProperties.Builder()
                    .nutrition(6).saturationMod(0.8F).alwaysEat()
                    .effect(() -> new MobEffectInstance(MobEffects.ABSORPTION, 1200, 1), 1.0F)
                    .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 100, 0), 1.0F)
                    .build())));

    // ---- Limonita: polo helado (fresquito contra el fuego) ----
    public static final RegistryObject<Item> LIMONITA_POPSICLE = ITEMS.register("limonita_popsicle",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .nutrition(4).saturationMod(0.5F).alwaysEat()
                    .effect(() -> new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 1200, 0), 1.0F)
                    .effect(() -> new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 400, 0), 1.0F)
                    .build())));

    // ---- Chocolita: bombon con energia ----
    public static final RegistryObject<Item> CHOCOLITA_BONBON = ITEMS.register("chocolita_bonbon",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .nutrition(3).saturationMod(0.6F).fast()
                    .effect(() -> new MobEffectInstance(MobEffects.DIG_SPEED, 300, 0), 1.0F)
                    .build())));

    // ---- Estrellita: detector de gemas ----
    public static final RegistryObject<Item> ESTRELLITA_DETECTOR = ITEMS.register("estrellita_detector",
            () -> new DetectorItem(new Item.Properties().durability(80).rarity(Rarity.UNCOMMON)));

    // ---- Lunita: campana que trae la noche ----
    public static final RegistryObject<Item> LUNITA_BELL = ITEMS.register("lunita_bell",
            () -> new SkyItem(false, new Item.Properties().durability(8).rarity(Rarity.RARE)));

    // ---- Solita: orbe que trae el dia y despeja el cielo ----
    public static final RegistryObject<Item> SOLITA_ORB = ITEMS.register("solita_orb",
            () -> new SkyItem(true, new Item.Properties().durability(8).rarity(Rarity.RARE)));

    // ---- Coralita: caracola que llama a tus gemoides ----
    public static final RegistryObject<Item> CORALITA_CONCH = ITEMS.register("coralita_conch",
            () -> new ConchItem(new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));

    // ---- Perlita: colgante protector ----
    public static final RegistryObject<Item> PERLITA_PENDANT = ITEMS.register("perlita_pendant",
            () -> new CharmItem(new Item.Properties().stacksTo(1).rarity(Rarity.RARE), () -> List.of(
                    new MobEffectInstance(MobEffects.ABSORPTION, 100, 1, true, false, true),
                    new MobEffectInstance(MobEffects.REGENERATION, 100, 0, true, false, true))));

    // ---- Iridita: prisma de efectos sorpresa ----
    public static final RegistryObject<Item> IRIDITA_PRISM = ITEMS.register("iridita_prism",
            () -> new PrismItem(new Item.Properties().durability(12).rarity(Rarity.EPIC)));

    // ======================================================================
    // Armaduras de Rubi y Zafiro
    // ======================================================================
    public static final RegistryObject<Item> RUBI_HELMET = armor("rubi_helmet", ModArmorMaterials.RUBI, ArmorItem.Type.HELMET);
    public static final RegistryObject<Item> RUBI_CHESTPLATE = armor("rubi_chestplate", ModArmorMaterials.RUBI, ArmorItem.Type.CHESTPLATE);
    public static final RegistryObject<Item> RUBI_LEGGINGS = armor("rubi_leggings", ModArmorMaterials.RUBI, ArmorItem.Type.LEGGINGS);
    public static final RegistryObject<Item> RUBI_BOOTS = armor("rubi_boots", ModArmorMaterials.RUBI, ArmorItem.Type.BOOTS);
    public static final RegistryObject<Item> ZAFIRO_HELMET = armor("zafiro_helmet", ModArmorMaterials.ZAFIRO, ArmorItem.Type.HELMET);
    public static final RegistryObject<Item> ZAFIRO_CHESTPLATE = armor("zafiro_chestplate", ModArmorMaterials.ZAFIRO, ArmorItem.Type.CHESTPLATE);
    public static final RegistryObject<Item> ZAFIRO_LEGGINGS = armor("zafiro_leggings", ModArmorMaterials.ZAFIRO, ArmorItem.Type.LEGGINGS);
    public static final RegistryObject<Item> ZAFIRO_BOOTS = armor("zafiro_boots", ModArmorMaterials.ZAFIRO, ArmorItem.Type.BOOTS);

    // ======================================================================
    // Los cuatro Diamantes de la Autoridad y sus cetros
    // ======================================================================
    public static final RegistryObject<Item> PINK_DIAMOND = diamond("pink_diamond", DiamondType.PINK);
    public static final RegistryObject<Item> YELLOW_DIAMOND = diamond("yellow_diamond", DiamondType.YELLOW);
    public static final RegistryObject<Item> BLUE_DIAMOND = diamond("blue_diamond", DiamondType.BLUE);
    public static final RegistryObject<Item> WHITE_DIAMOND = diamond("white_diamond", DiamondType.WHITE);

    public static final RegistryObject<Item> PINK_SCEPTER = scepter("pink_scepter", DiamondType.PINK);
    public static final RegistryObject<Item> YELLOW_SCEPTER = scepter("yellow_scepter", DiamondType.YELLOW);
    public static final RegistryObject<Item> BLUE_SCEPTER = scepter("blue_scepter", DiamondType.BLUE);
    public static final RegistryObject<Item> WHITE_SCEPTER = scepter("white_scepter", DiamondType.WHITE);

    // ---- Huevos de gemoide (uno por gema) ----
    static {
        for (GemType type : GemType.values()) {
            ITEMS.register(type.id() + "_gemoid_egg", () -> new GemoidEggItem(type, new Item.Properties()));
        }
    }

    private static RegistryObject<Item> armor(String name, ModArmorMaterials material, ArmorItem.Type type) {
        return ITEMS.register(name, () -> new ArmorItem(material, type, new Item.Properties()));
    }

    private static RegistryObject<Item> diamond(String name, DiamondType type) {
        return ITEMS.register(name, () -> new DiamondItem(type, new Item.Properties()
                .rarity(Rarity.EPIC).fireResistant()));
    }

    private static RegistryObject<Item> scepter(String name, DiamondType type) {
        return ITEMS.register(name, () -> new DiamondScepterItem(type, new Item.Properties()
                .durability(type.durability()).rarity(Rarity.EPIC).fireResistant()));
    }

    private static RegistryObject<Item> gem(String name, Rarity rarity) {
        return ITEMS.register(name, () -> new Item(new Item.Properties().rarity(rarity)));
    }
}
