package com.gemascute.registry;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;

/** Armaduras de gema. El nombre lleva el id del mod para que Forge busque la textura en gemascute. */
public enum ModArmorMaterials implements ArmorMaterial {
    RUBI("gemascute:rubi", 32, 3, 7, 6, 3, 20, 1.0F, 0.0F),
    ZAFIRO("gemascute:zafiro", 32, 3, 7, 6, 3, 22, 1.0F, 0.0F);

    private final String name;
    private final int durabilityMultiplier;
    private final int helmet;
    private final int chest;
    private final int legs;
    private final int boots;
    private final int enchantability;
    private final float toughness;
    private final float knockbackResistance;

    ModArmorMaterials(String name, int durabilityMultiplier, int helmet, int chest, int legs, int boots,
                      int enchantability, float toughness, float knockbackResistance) {
        this.name = name;
        this.durabilityMultiplier = durabilityMultiplier;
        this.helmet = helmet;
        this.chest = chest;
        this.legs = legs;
        this.boots = boots;
        this.enchantability = enchantability;
        this.toughness = toughness;
        this.knockbackResistance = knockbackResistance;
    }

    @Override
    public int getDurabilityForType(ArmorItem.Type type) {
        int base = switch (type) {
            case HELMET -> 11;
            case CHESTPLATE -> 16;
            case LEGGINGS -> 15;
            case BOOTS -> 13;
        };
        return base * this.durabilityMultiplier;
    }

    @Override
    public int getDefenseForType(ArmorItem.Type type) {
        return switch (type) {
            case HELMET -> this.helmet;
            case CHESTPLATE -> this.chest;
            case LEGGINGS -> this.legs;
            case BOOTS -> this.boots;
        };
    }

    @Override
    public int getEnchantmentValue() {
        return this.enchantability;
    }

    @Override
    public SoundEvent getEquipSound() {
        return SoundEvents.ARMOR_EQUIP_DIAMOND;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return this == RUBI ? Ingredient.of(ModItems.RUBI.get()) : Ingredient.of(ModItems.ZAFIRO.get());
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public float getToughness() {
        return this.toughness;
    }

    @Override
    public float getKnockbackResistance() {
        return this.knockbackResistance;
    }
}
