package com.gemascute.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.BoneMealItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

/** Bloque de Mentita: de vez en cuando hace crecer las plantas que tiene alrededor. */
public class FertileBlock extends Block {
    public FertileBlock(Properties properties) {
        super(properties);
    }

    @Override
    public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        for (int i = 0; i < 4; i++) {
            BlockPos target = pos.offset(random.nextInt(9) - 4, random.nextInt(5) - 2, random.nextInt(9) - 4);
            if (BoneMealItem.growCrop(new ItemStack(Items.BONE_MEAL), level, target)) {
                level.sendParticles(ParticleTypes.HAPPY_VILLAGER, target.getX() + 0.5D, target.getY() + 0.8D,
                        target.getZ() + 0.5D, 6, 0.3D, 0.3D, 0.3D, 0.0D);
                break;
            }
        }
    }
}
