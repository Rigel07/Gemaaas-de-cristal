package com.gemascute.event;

import com.gemascute.GemasCuteMod;
import com.gemascute.entity.GemType;
import com.gemascute.entity.GemoidEntity;
import com.gemascute.item.DiamondType;
import com.gemascute.registry.ModArmorMaterials;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.List;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Efectos que no pertenecen a un solo objeto: bonus de armadura completa, poderes pasivos de los
 * Diamantes de la Autoridad y las habilidades de Rubi (fuego) y Zafiro (esquivar).
 */
@Mod.EventBusSubscriber(modid = GemasCuteMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class ForgeEvents {

    // ------------------------------------------------------------ Cada segundo

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.side.isClient()) {
            return;
        }
        Player player = event.player;
        if (player.tickCount % 20 != 0 || !(player.level() instanceof ServerLevel level)) {
            return;
        }

        // Armadura completa de gema
        if (hasFullSet(player, ModArmorMaterials.RUBI)) {
            buff(player, MobEffects.FIRE_RESISTANCE, 0);
            buff(player, MobEffects.DAMAGE_BOOST, 0);
        }
        if (hasFullSet(player, ModArmorMaterials.ZAFIRO)) {
            buff(player, MobEffects.WATER_BREATHING, 0);
            buff(player, MobEffects.DAMAGE_RESISTANCE, 0);
        }

        // Diamantes de la Autoridad en la barra rapida
        EnumSet<DiamondType> held = DiamondType.held(player);
        if (held.isEmpty()) {
            return;
        }
        List<GemoidEntity> allies = level.getEntitiesOfClass(GemoidEntity.class,
                player.getBoundingBox().inflate(24.0D), g -> g.isTame() && g.isOwnedBy(player));

        if (held.contains(DiamondType.PINK)) {
            buff(player, MobEffects.REGENERATION, 0);
            for (GemoidEntity gemoid : allies) {
                buff(gemoid, MobEffects.REGENERATION, 1);
            }
        }
        if (held.contains(DiamondType.YELLOW)) {
            buff(player, MobEffects.DIG_SPEED, 0);
            for (GemoidEntity gemoid : allies) {
                buff(gemoid, MobEffects.DAMAGE_BOOST, 0);
            }
        }
        if (held.contains(DiamondType.BLUE)) {
            buff(player, MobEffects.DAMAGE_RESISTANCE, 0);
            for (GemoidEntity gemoid : allies) {
                buff(gemoid, MobEffects.DAMAGE_RESISTANCE, 0);
            }
            // Aura de pesar: los monstruos cercanos se quedan lentos y flojos
            for (Monster monster : level.getEntitiesOfClass(Monster.class, player.getBoundingBox().inflate(8.0D),
                    LivingEntity::isAlive)) {
                monster.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 0, true, false, false));
                monster.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 60, 0, true, false, false));
            }
        }
        if (held.contains(DiamondType.WHITE)) {
            buff(player, MobEffects.DAMAGE_RESISTANCE, 0);
            buff(player, MobEffects.DAMAGE_BOOST, 0);
            buff(player, MobEffects.REGENERATION, 0);
            for (GemoidEntity gemoid : allies) {
                buff(gemoid, MobEffects.DAMAGE_RESISTANCE, 1);
                buff(gemoid, MobEffects.DAMAGE_BOOST, 1);
                buff(gemoid, MobEffects.REGENERATION, 1);
                buff(gemoid, MobEffects.MOVEMENT_SPEED, 0);
            }
        }
    }

    private static void buff(LivingEntity entity, MobEffect effect, int amplifier) {
        entity.addEffect(new MobEffectInstance(effect, 100, amplifier, true, false, true));
    }

    // ----------------------------------------------------- Rubi: quien te pega, arde

    @SubscribeEvent
    public static void onHurt(LivingHurtEvent event) {
        if (!(event.getEntity() instanceof Player player) || player.level().isClientSide) {
            return;
        }
        if (!(event.getSource().getEntity() instanceof LivingEntity attacker) || attacker == player) {
            return;
        }
        if (hasAlly(player, GemType.RUBI, GemType.GRANATE) || hasFullSet(player, ModArmorMaterials.RUBI)) {
            attacker.setSecondsOnFire(5);
        }
    }

    // ------------------------------------------------ Zafiro: ve el golpe venir

    @SubscribeEvent
    public static void onAttack(LivingAttackEvent event) {
        if (!(event.getEntity() instanceof Player player) || !(player.level() instanceof ServerLevel level)) {
            return;
        }
        DamageSource source = event.getSource();
        if (source.getEntity() == null || source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return;
        }
        float chance = 0.0F;
        if (hasAlly(player, GemType.ZAFIRO, GemType.GRANATE)) {
            chance += 0.20F;
        }
        if (hasFullSet(player, ModArmorMaterials.ZAFIRO)) {
            chance += 0.15F;
        }
        if (chance > 0.0F && player.getRandom().nextFloat() < chance) {
            event.setCanceled(true);
            level.sendParticles(ParticleTypes.ENCHANT, player.getX(), player.getY() + 1.0D, player.getZ(),
                    12, 0.4D, 0.6D, 0.4D, 0.3D);
            level.playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME,
                    SoundSource.PLAYERS, 0.8F, 1.9F);
        }
    }

    // ---------------------------------------------------------------- Ayudas

    private static boolean hasAlly(Player player, GemType... types) {
        List<GemType> wanted = Arrays.asList(types);
        return !player.level().getEntitiesOfClass(GemoidEntity.class, player.getBoundingBox().inflate(16.0D),
                g -> g.isTame() && g.isOwnedBy(player) && wanted.contains(g.getGemType())).isEmpty();
    }

    private static boolean hasFullSet(Player player, ArmorMaterial material) {
        int pieces = 0;
        for (ItemStack stack : player.getArmorSlots()) {
            if (stack.getItem() instanceof ArmorItem armor && armor.getMaterial() == material) {
                pieces++;
            }
        }
        return pieces == 4;
    }
}
