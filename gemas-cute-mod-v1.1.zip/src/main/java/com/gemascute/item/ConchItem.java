package com.gemascute.item;

import com.gemascute.entity.GemoidEntity;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Caracola de Coralita: clic derecho = tus gemoides amigos (hasta 64 bloques) acuden a ti. */
public class ConchItem extends Item {
    public ConchItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level instanceof ServerLevel server) {
            int called = 0;
            for (GemoidEntity gemoid : server.getEntitiesOfClass(GemoidEntity.class,
                    player.getBoundingBox().inflate(64.0D), g -> g.isTame() && g.isOwnedBy(player))) {
                double x = player.getX() + (server.random.nextDouble() - 0.5D) * 3.0D;
                double z = player.getZ() + (server.random.nextDouble() - 0.5D) * 3.0D;
                gemoid.setOrderedToSit(false);
                gemoid.getNavigation().stop();
                if (!gemoid.randomTeleport(x, player.getY(), z, true)) {
                    gemoid.teleportTo(player.getX(), player.getY(), player.getZ());
                }
                server.sendParticles(ParticleTypes.NOTE, gemoid.getX(), gemoid.getY() + 1.2D, gemoid.getZ(),
                        3, 0.3D, 0.3D, 0.3D, 0.1D);
                called++;
            }
            level.playSound(null, player.blockPosition(), SoundEvents.CONDUIT_ACTIVATE, SoundSource.PLAYERS, 1.0F, 1.5F);
            if (called == 0) {
                player.displayClientMessage(Component.translatable("message.gemascute.conch_none"), true);
            }
            player.getCooldowns().addCooldown(this, 200);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }
}
