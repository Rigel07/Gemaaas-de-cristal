package com.gemascute.item;

import com.gemascute.GemasCuteMod;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.registries.ForgeRegistries;

/** Detector de Estrellita: clic derecho = te dice cual es la mena de gema mas cercana (radio 14). */
public class DetectorItem extends Item {
    private static final int RADIUS = 14;

    public DetectorItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level instanceof ServerLevel server) {
            BlockPos origin = player.blockPosition();
            BlockPos best = null;
            double bestDist = Double.MAX_VALUE;
            for (BlockPos pos : BlockPos.betweenClosed(origin.offset(-RADIUS, -RADIUS, -RADIUS),
                    origin.offset(RADIUS, RADIUS, RADIUS))) {
                Block block = level.getBlockState(pos).getBlock();
                var key = ForgeRegistries.BLOCKS.getKey(block);
                if (key != null && key.getNamespace().equals(GemasCuteMod.MODID) && key.getPath().endsWith("_ore")) {
                    double dist = pos.distSqr(origin);
                    if (dist < bestDist) {
                        bestDist = dist;
                        best = pos.immutable();
                    }
                }
            }
            if (best == null) {
                player.displayClientMessage(Component.translatable("message.gemascute.detector_none"), true);
            } else {
                Direction dir = Direction.getNearest(best.getX() - origin.getX(),
                        best.getY() - origin.getY(), best.getZ() - origin.getZ());
                Component name = level.getBlockState(best).getBlock().getName();
                player.displayClientMessage(Component.translatable("message.gemascute.detector_found",
                        name, (int) Math.round(Math.sqrt(bestDist)),
                        Component.translatable("direction.gemascute." + dir.getName())), true);
                server.sendParticles(ParticleTypes.END_ROD, player.getX(), player.getY() + 1.0D, player.getZ(),
                        6, 0.3D, 0.3D, 0.3D, 0.02D);
                level.playSound(null, origin, SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.0F, 1.7F);
                stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
            }
            player.getCooldowns().addCooldown(this, 40);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }
}
