package com.gemascute.item;

import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/**
 * Diamante de la Autoridad. Llevarlo en la barra rapida da un poder pasivo (ver ForgeEvents)
 * y hace mas fuertes las auras de tus gemoides. Con clic derecho sobre un gemoide usa su poder
 * (ver GemoidEntity#diamondInteract).
 */
public class DiamondItem extends Item {
    private final DiamondType type;

    public DiamondItem(DiamondType type, Properties properties) {
        super(properties);
        this.type = type;
    }

    public DiamondType type() {
        return this.type;
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.gemascute." + this.type.id() + "_diamond.passive")
                .withStyle(this.type.color()));
        tooltip.add(Component.translatable("tooltip.gemascute." + this.type.id() + "_diamond.use")
                .withStyle(ChatFormatting.GRAY));
    }
}
