package com.gemascute.item;

import com.gemascute.entity.GemoidEntity;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/** Cetro de un Diamante: clic derecho = el gran poder de ese diamante sobre tus gemoides y los monstruos. */
public class DiamondScepterItem extends Item {
    private final DiamondType type;

    public DiamondScepterItem(DiamondType type, Properties properties) {
        super(properties);
        this.type = type;
    }

    public DiamondType type() {
        return this.type;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level instanceof ServerLevel server) {
            boolean used = switch (this.type) {
                case PINK -> pink(server, player);
                case YELLOW -> yellow(server, player);
                case BLUE -> blue(server, player);
                case WHITE -> white(server, player);
            };
            if (used) {
                stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
                player.getCooldowns().addCooldown(this, this.type.cooldown());
            }
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    // ---------------------------------------------------------------- Poderes

    /** Rosa: vida. Cura a ti y a todos tus gemoides y los deja regenerando. */
    private static boolean pink(ServerLevel level, Player player) {
        player.heal(20.0F);
        player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 2));
        player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 1200, 1));
        burst(level, player, ParticleTypes.HEART);
        for (GemoidEntity gemoid : allies(level, player, 24.0D)) {
            gemoid.heal(gemoid.getMaxHealth());
            gemoid.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 2));
            burst(level, gemoid, ParticleTypes.HEART);
        }
        level.playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.0F, 0.7F);
        return true;
    }

    /** Amarillo: mando. Tus gemoides se lanzan contra el monstruo mas cercano, con fuerza y velocidad. */
    private static boolean yellow(ServerLevel level, Player player) {
        Monster target = null;
        double best = Double.MAX_VALUE;
        for (Monster monster : level.getEntitiesOfClass(Monster.class, player.getBoundingBox().inflate(24.0D),
                LivingEntity::isAlive)) {
            double dist = monster.distanceToSqr(player);
            if (dist < best) {
                best = dist;
                target = monster;
            }
        }
        List<GemoidEntity> allies = allies(level, player, 32.0D);
        if (target == null || allies.isEmpty()) {
            player.displayClientMessage(Component.translatable("message.gemascute.nothing_to_command"), true);
            return false;
        }
        for (GemoidEntity gemoid : allies) {
            gemoid.setOrderedToSit(false);
            gemoid.setTarget(target);
            gemoid.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 400, 1));
            gemoid.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 400, 1));
            burst(level, gemoid, ParticleTypes.TOTEM_OF_UNDYING);
        }
        burst(level, player, ParticleTypes.TOTEM_OF_UNDYING);
        level.playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.PLAYERS, 1.0F, 1.2F);
        return true;
    }

    /** Azul: calma. Los monstruos cercanos se quedan tristes y flojos; tu equipo se protege y se limpia. */
    private static boolean blue(ServerLevel level, Player player) {
        for (Monster monster : level.getEntitiesOfClass(Monster.class, player.getBoundingBox().inflate(12.0D),
                LivingEntity::isAlive)) {
            monster.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 200, 2));
            monster.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 200, 1));
            monster.addEffect(new MobEffectInstance(MobEffects.GLOWING, 200, 0));
            burst(level, monster, ParticleTypes.FALLING_WATER);
        }
        cleanse(player);
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 300, 1));
        burst(level, player, ParticleTypes.FALLING_WATER);
        for (GemoidEntity gemoid : allies(level, player, 24.0D)) {
            cleanse(gemoid);
            gemoid.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 300, 1));
            burst(level, gemoid, ParticleTypes.FALLING_WATER);
        }
        level.playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.0F, 0.5F);
        return true;
    }

    /** Blanco: supremacia. Tus gemoides se vuelven intocables y feroces; los monstruos salen despedidos. */
    private static boolean white(ServerLevel level, Player player) {
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 400, 1));
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 400, 1));
        player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 400, 1));
        burst(level, player, ParticleTypes.END_ROD);
        for (GemoidEntity gemoid : allies(level, player, 48.0D)) {
            gemoid.heal(gemoid.getMaxHealth());
            gemoid.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 400, 4));
            gemoid.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 600, 2));
            gemoid.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 600, 1));
            gemoid.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 400, 2));
            burst(level, gemoid, ParticleTypes.END_ROD);
        }
        for (Monster monster : level.getEntitiesOfClass(Monster.class, player.getBoundingBox().inflate(16.0D),
                LivingEntity::isAlive)) {
            monster.knockback(1.6D, player.getX() - monster.getX(), player.getZ() - monster.getZ());
            monster.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 3));
            monster.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 200, 2));
            burst(level, monster, ParticleTypes.END_ROD);
        }
        level.playSound(null, player.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.0F, 1.4F);
        return true;
    }

    // ---------------------------------------------------------------- Ayudas

    private static List<GemoidEntity> allies(ServerLevel level, Player player, double range) {
        return level.getEntitiesOfClass(GemoidEntity.class, player.getBoundingBox().inflate(range),
                gemoid -> gemoid.isTame() && gemoid.isOwnedBy(player));
    }

    private static void cleanse(LivingEntity entity) {
        for (MobEffectInstance active : new java.util.ArrayList<>(entity.getActiveEffects())) {
            if (active.getEffect().getCategory() == MobEffectCategory.HARMFUL) {
                entity.removeEffect(active.getEffect());
            }
        }
    }

    private static void burst(ServerLevel level, LivingEntity entity, ParticleOptions particle) {
        level.sendParticles(particle, entity.getX(), entity.getY() + 1.0D, entity.getZ(),
                10, 0.4D, 0.5D, 0.4D, 0.05D);
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.gemascute." + this.type.id() + "_scepter")
                .withStyle(this.type.color()));
        tooltip.add(Component.translatable("tooltip.gemascute.scepter_hint").withStyle(ChatFormatting.GRAY));
    }
}
