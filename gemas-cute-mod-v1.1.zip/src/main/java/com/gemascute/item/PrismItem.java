package com.gemascute.item;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Prisma de Iridita: clic derecho = un efecto bueno al azar durante un minuto (¡sorpresa arcoiris!). */
public class PrismItem extends Item {
    private static final MobEffect[] EFFECTS = {
            MobEffects.MOVEMENT_SPEED, MobEffects.DAMAGE_BOOST, MobEffects.REGENERATION,
            MobEffects.DAMAGE_RESISTANCE, MobEffects.JUMP, MobEffects.NIGHT_VISION,
            MobEffects.DIG_SPEED, MobEffects.LUCK, MobEffects.FIRE_RESISTANCE
    };

    public PrismItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level instanceof ServerLevel server) {
            MobEffect effect = EFFECTS[server.random.nextInt(EFFECTS.length)];
            player.addEffect(new MobEffectInstance(effect, 1200, 1));
            server.sendParticles(ParticleTypes.HAPPY_VILLAGER, player.getX(), player.getY() + 1.0D, player.getZ(),
                    12, 0.4D, 0.5D, 0.4D, 0.05D);
            level.playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME,
                    SoundSource.PLAYERS, 1.0F, 1.2F + server.random.nextFloat() * 0.6F);
            stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
            player.getCooldowns().addCooldown(this, 100);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }
}
