package com.gemascute.item;

import java.util.EnumSet;
import net.minecraft.ChatFormatting;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/**
 * Los cuatro Diamantes de la Autoridad. Cada uno manda sobre las gemas de una forma distinta.
 * Rosa = vida, Amarillo = mando, Azul = calma y proteccion, Blanco = supremacia (los reune a todos).
 */
public enum DiamondType {
    PINK("pink", ChatFormatting.LIGHT_PURPLE, 1200, 30),
    YELLOW("yellow", ChatFormatting.YELLOW, 600, 30),
    BLUE("blue", ChatFormatting.BLUE, 900, 30),
    WHITE("white", ChatFormatting.WHITE, 3600, 12);

    private final String id;
    private final ChatFormatting color;
    private final int cooldown;
    private final int durability;

    DiamondType(String id, ChatFormatting color, int cooldown, int durability) {
        this.id = id;
        this.color = color;
        this.cooldown = cooldown;
        this.durability = durability;
    }

    public String id() { return this.id; }
    public ChatFormatting color() { return this.color; }
    /** Espera del cetro, en ticks. */
    public int cooldown() { return this.cooldown; }
    /** Usos del cetro. */
    public int durability() { return this.durability; }

    /** A que diamante pertenece un objeto (el diamante o su cetro), o null si a ninguno. */
    public static DiamondType of(ItemStack stack) {
        if (stack.getItem() instanceof DiamondItem diamond) {
            return diamond.type();
        }
        if (stack.getItem() instanceof DiamondScepterItem scepter) {
            return scepter.type();
        }
        return null;
    }

    /** Los diamantes (o cetros) que lleva el jugador en la barra rapida o en la mano izquierda. */
    public static EnumSet<DiamondType> held(Player player) {
        EnumSet<DiamondType> set = EnumSet.noneOf(DiamondType.class);
        for (int i = 0; i < 9; i++) {
            DiamondType type = of(player.getInventory().getItem(i));
            if (type != null) {
                set.add(type);
            }
        }
        DiamondType off = of(player.getOffhandItem());
        if (off != null) {
            set.add(off);
        }
        return set;
    }
}
