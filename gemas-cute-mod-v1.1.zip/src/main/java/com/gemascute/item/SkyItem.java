package com.gemascute.item;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * Campana de Lunita (hace de noche) y Orbe de Solita (hace de dia y despeja el cielo).
 * Solo cambian la hora cuando hace falta; si ya es lo que pides, no gastan usos.
 */
public class SkyItem extends Item {
    private final boolean makeDay;

    public SkyItem(boolean makeDay, Properties properties) {
        super(properties);
        this.makeDay = makeDay;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level instanceof ServerLevel server) {
            long time = server.getDayTime();
            long dayStart = time - (time % 24000L);
            boolean night = (time % 24000L) >= 12500L;
            boolean changed = false;
            if (this.makeDay) {
                if (night) {
                    server.setDayTime(dayStart + 24000L);
                    changed = true;
                }
                if (server.isRaining() || server.isThundering()) {
                    server.setWeatherParameters(12000, 0, false, false);
                    changed = true;
                }
            } else if (!night) {
                server.setDayTime(dayStart + 13000L);
                changed = true;
            }
            if (changed) {
                server.sendParticles(this.makeDay ? ParticleTypes.FLAME : ParticleTypes.END_ROD,
                        player.getX(), player.getY() + 1.5D, player.getZ(), 20, 0.5D, 0.5D, 0.5D, 0.05D);
                level.playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_RESONATE,
                        SoundSource.PLAYERS, 1.0F, this.makeDay ? 1.6F : 0.6F);
                stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
                player.getCooldowns().addCooldown(this, 200);
            } else {
                player.displayClientMessage(Component.translatable(this.makeDay
                        ? "message.gemascute.already_day" : "message.gemascute.already_night"), true);
            }
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }
}
